﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Core.Dtos;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace LibraryManagementSystem.Controllers
{
    [ApiController]
    [Route("api/admin")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase  // Changed from Controller to ControllerBase
    {
        private readonly LibraryDbContext _context;  // Changed from DataBaseContext to LibraryDbContext

        public AdminController(LibraryDbContext context)  // Changed parameter type
        {
            _context = context;
        }

        [HttpGet("all-users")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _context.Users
                .Select(u => new UserDto
                {
                    UserID = u.UserID,
                    Name = u.Name,
                    Role = u.Role,
                    Email = u.Email
                })
                .ToListAsync();

            return Ok(users);
        }

        [HttpGet("all-books")]
        public async Task<IActionResult> GetAllBooks()
        {
            var books = await _context.Books
                .Include(b => b.Category)
                .Select(b => new BookDto
                {
                    BookID = b.BookID,
                    Title = b.Title,
                    Author = b.Author,
                    ISBN = b.ISBN,
                    Quantity = b.Quantity,
                    CategoryID = b.CategoryID,
                    Category = b.Category.Name
                })
                .ToListAsync();

            return Ok(books);
        }

        [HttpGet("all-categories")]
        public async Task<IActionResult> GetAllCategories()
        {
            var categories = await _context.Categories
                .Select(c => new CategoryDto
                {
                    CategoryID = c.CategoryID,
                    Name = c.Name
                })
                .ToListAsync();

            return Ok(categories);
        }

        [HttpGet("all-issued-books")]
        public async Task<IActionResult> GetAllIssuedBooks()
        {
            var issuedBooks = await _context.Issues
                .Include(i => i.Book)
                .Include(i => i.User)
                .Select(i => new IssueDto
                {
                    IssueID = i.IssueID,
                    BookID = i.BookID,
                    UserID = i.UserID,
                    IssueDate = i.IssueDate,
                    DueDate = i.DueDate,
                    ReturnDate = i.ReturnDate,
                    FineAmount = i.FineAmount
                })
                .ToListAsync();

            return Ok(issuedBooks);
        }
    }
}