﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Core.Dtos;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace LibraryManagementSystem.Controllers
{
    [ApiController]
    [Route("api/books")]
    public class BookController : ControllerBase
    {
        private readonly LibraryDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public BookController(LibraryDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<BookDto>>> GetBooks()
        {
            return await _context.Books
                .Include(b => b.Category)
                .Select(b => new BookDto
                {
                    BookID = b.BookID,
                    Title = b.Title,
                    Author = b.Author,
                    ISBN = b.ISBN,
                    Quantity = b.Quantity,
                    CategoryID = b.CategoryID,
                    Category = b.Category != null ? b.Category.Name : "Unknown"
                })
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BookDto>> GetBook(int id)
        {
            var book = await _context.Books
                .Include(b => b.Category)
                .FirstOrDefaultAsync(b => b.BookID == id);

            if (book == null) return NotFound();

            return new BookDto
            {
                BookID = book.BookID,
                Title = book.Title,
                Author = book.Author,
                ISBN = book.ISBN,
                Quantity = book.Quantity,
                CategoryID = book.CategoryID,
                Category = book.Category.Name
            };
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<Book>> AddBook(BookCreateDto bookDto)
        {
            var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == bookDto.CategoryID);
            if (!categoryExists) return BadRequest("Invalid category ID");

            var book = new Book
            {
                Title = bookDto.Title,
                Author = bookDto.Author,
                ISBN = bookDto.ISBN,
                Quantity = bookDto.Quantity,
                CategoryID = bookDto.CategoryID
            };

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetBook), new { id = book.BookID }, book);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateBook(int id, BookUpdateDto bookDto)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            if (bookDto.CategoryID.HasValue)
            {
                var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == bookDto.CategoryID);
                if (!categoryExists) return BadRequest("Invalid category ID");
            }

            book.Title = bookDto.Title ?? book.Title;
            book.Author = bookDto.Author ?? book.Author;
            book.ISBN = bookDto.ISBN ?? book.ISBN;
            book.Quantity = bookDto.Quantity ?? book.Quantity;
            book.CategoryID = bookDto.CategoryID ?? book.CategoryID;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost("{id}/borrow")]
        [Authorize(Roles = "Member")]
        public async Task<ActionResult<IssueDto>> BorrowBook(int id)
        {
            var userName = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Name);
            if (string.IsNullOrEmpty(userName)) return Unauthorized();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Name == userName);
            if (user == null) return Unauthorized();

            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();
            if (book.Quantity <= 0) return BadRequest("Book unavailable");

            book.Quantity--;

            var borrowRecord = new Issue
            {
                UserID = user.UserID,
                BookID = book.BookID,
                IssueDate = DateTime.UtcNow,
                DueDate = DateTime.UtcNow.AddDays(14), // Example due date
                FineAmount = 0
            };

            _context.Issues.Add(borrowRecord);
            await _context.SaveChangesAsync();

            return Ok(new IssueDto
            {
                IssueID = borrowRecord.IssueID,
                BookID = borrowRecord.BookID,
                UserID = borrowRecord.UserID,
                IssueDate = borrowRecord.IssueDate,
                DueDate = borrowRecord.DueDate,
                ReturnDate = borrowRecord.ReturnDate,
                FineAmount = borrowRecord.FineAmount
            });
        }

        [HttpPut("{id}/return")]
        [Authorize(Roles = "Member")]
        public async Task<IActionResult> ReturnBook(int id)
        {
            var userName = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Name);
            if (string.IsNullOrEmpty(userName)) return Unauthorized();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Name == userName);
            if (user == null) return Unauthorized();

            var issuedBook = await _context.Issues
                .FirstOrDefaultAsync(i => i.BookID == id && i.UserID == user.UserID && i.ReturnDate == null);

            if (issuedBook == null) return BadRequest("No active borrowing record found");

            var book = await _context.Books.FindAsync(id);
            if (book == null) return NotFound();

            issuedBook.ReturnDate = DateTime.UtcNow;
            book.Quantity++;

            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}