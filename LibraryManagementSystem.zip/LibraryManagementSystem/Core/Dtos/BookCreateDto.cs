using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Core.Dtos
{
	public class BookCreateDto
	{
		[Required]
		public string Title { get; set; } = string.Empty;

		[Required]
		public string Author { get; set; } = string.Empty;

		public string ISBN { get; set; } = string.Empty;
		public int CategoryID { get; set; }
		public int Quantity { get; set; } = 1;
	}
}