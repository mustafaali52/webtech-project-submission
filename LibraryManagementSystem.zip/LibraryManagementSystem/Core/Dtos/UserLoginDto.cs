namespace LibraryManagementSystem.Core.Dtos
{
	public class UserLoginDto
	{
		public string Name { get; set; } = string.Empty;
		public string Password { get; set; } = string.Empty;
	}
}