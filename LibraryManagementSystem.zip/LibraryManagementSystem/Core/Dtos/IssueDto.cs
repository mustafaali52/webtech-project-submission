dnamespace LibraryManagementSystem.Core.Dtos
{
    public class IssueDto
    {
        public int IssueID { get; set; }
        public int UserID { get; set; }
        public int BookID { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public decimal FineAmount { get; set; }
    }
} 