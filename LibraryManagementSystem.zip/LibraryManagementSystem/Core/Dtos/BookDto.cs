﻿namespace LibraryManagementSystem.Core.Dtos
{
    public class BookDto
    {
        public int BookID { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string ISBN { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public int CategoryID { get; set; }
        public string Category { get; set; } = string.Empty;
    }
}