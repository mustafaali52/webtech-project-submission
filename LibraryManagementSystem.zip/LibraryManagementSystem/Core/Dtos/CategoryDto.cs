﻿namespace LibraryManagementSystem.Core.Dtos
{
    public class CategoryDto
    {
        public int CategoryID { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}