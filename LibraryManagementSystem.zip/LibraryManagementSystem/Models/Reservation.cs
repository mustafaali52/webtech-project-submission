﻿namespace LibraryManagementSystem.Models
{
    public class Reservation
    {
        public int ReservationID { get; set; }
        public int BookID { get; set; }
        public int UserID { get; set; }
        public DateTime ReservationDate { get; set; }
        public string Status { get; set; } = null!;

        // Navigation properties
        public Book Book { get; set; } = null!;
        public User User { get; set; } = null!;
    }
}
