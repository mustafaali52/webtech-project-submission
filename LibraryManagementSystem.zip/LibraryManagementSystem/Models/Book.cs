﻿namespace LibraryManagementSystem.Models
{
    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; } = null!;
        public string Author { get; set; } = null!;
        public string ISBN { get; set; } = null!;
        public int Quantity { get; set; }
        public int CategoryID { get; set; }

        // Navigation properties
        public Category Category { get; set; } = null!;
        public ICollection<Issue> Issues { get; set; } = new List<Issue>();
        public ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
    }
}
